$(function(){
	/*左边导航*/
	$(document).scroll(function(){
		if($(document).scrollTop()>=145){
			$('.side_left').css({
				'position':'fixed',
				'top':'20px',
				'left':'20px'
			});
		}else{
			$('.side_left').css({
				'position':'absolute',
				'top':'0',
				'left':'0'
			});
		}
	});
	
	var minHeight = $('.person_echarts').height();
	$('.person_con').css('min-height',minHeight+30+'px');
	
	
	$('.radar_btn a').click(function(){
		tab(this,'.radar_item','radar_btn_active');
	});
	
	$('.data_btn a').click(function(){
		tab(this,'.data_item','radar_btn_active');
	});
	
	$('.progress_all').each(function(){
		var totalNum = 150;
		var recentNum = $(this).find('.progress_num').text();
		var rate = recentNum/totalNum*($(this).find('.progress').width());
		$(this).find('.progress span').css('width',rate+'px');
	});
	
	function tab(that,tab_hd,active_class)
	{
		$(that).addClass(active_class).siblings().removeClass(active_class);
		$(tab_hd).eq($(that).index()).show().siblings(tab_hd).hide();
	}

	$(".slide_content") .hover(function(){
			$(this) .children(".txt").stop() .animate({height:"360px"},200);
            $(this) .parent(".teacherPic") .css({"background":"url(img/"+($(this).attr('id'))+".jpg) no-repeat","-webkit-transition":"all 0.8s ease 0.2s","transition":"all 0.8s ease 0.2s"});
/*			$(this) .parent(".teacherPic") .css("background","url(img/"+($(this).attr('id'))+".jpg) no-repeat");*/
			$(this) .find(".txt h3").stop() .animate({paddingTop:"130"},550);
			$(this) .find(".txt p").stop() .show();
	},function(){
			$(this) .children(".txt").stop() .animate({height:"100px"},200);
			$(this) .find(".txt h3").stop().animate({paddingTop:"0px"},550);
			$(this) .find(".txt p").stop() .hide();
		});

	//点击遮罩
	$('.rec_list li').click(function(){
		if ($(this).hasClass('rec_list_active')) {
			$(this).removeClass('rec_list_active');
		}else{
			$(this).addClass('rec_list_active');
		}
	});
})