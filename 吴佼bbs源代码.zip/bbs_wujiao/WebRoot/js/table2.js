window.onload = function() {
	// jQ鐗堟湰
	// 鍥犱负鏍煎瓙鍐呯殑鎸夐敭浜嬩欢閮戒細浼犵粰澶栧眰锛屾墍浠ユ垜浠湪澶栧眰鎹曟崏鎸夐敭浜嬩欢
	$('#statstable').click(function (event) {
		// event.target鍙互瀹氫綅鍒版寜閿綅缃紝鎴戜滑鎵惧埌鐨勭埜鐖�tr>,鍐嶅湪tr閲岄潰鎵剧浜屼釜td
		var target = $(event.target).parent().find('td')[3];
		// 鑾峰彇鎷垮埌鐨勭洰鏍囧�浼犵粰url
		window.location.href = "comment_detail.jsp?comment_time="+ $(target).text();

	});

	// js鐗堟湰
	// document.getElementById('statstable').onclick = function (event) {
	// 	var matchid = event.target.parentNode.children[1].innerHTML
	// 	window.location.href="DetaiMatch.jsp?id="+matchid;
	// }
};