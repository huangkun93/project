package bbs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ws.rs.GET;

public class message {

	public void sendMessage(String message,String message_author) throws SQLException, ClassNotFoundException{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","1995494wujiao");
		Statement stat = con.createStatement();
		
		Date date=new Date();
		DateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time=format.format(date);
		
		String sql="INSERT INTO `message` (message,message_author,message_time) VALUES('"+message+"','"+message_author+"','"+time+"')";
		PreparedStatement ps=con.prepareStatement(sql);
		stat.execute(sql);
	}
	
	public List<comment_bean> getMessage() throws SQLException, ClassNotFoundException{
		List<comment_bean> list =new ArrayList<comment_bean>();
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","1995494wujiao");
		Statement stat = con.createStatement();
		String sql="SELECT * FROM `message` WHERE ishidden=1 ORDER BY message_time DESC";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		while (rs.next())
		{
			comment_bean record=new comment_bean();
			String message=rs.getString("message");
			String message_author=rs.getString("message_author");
			String message_time=rs.getString("message_time");
			int id=rs.getInt("id");
			
			
			record.setMessage(message);
			record.setMessage_author(message_author);
			
			record.setMessage_time(message_time);
			record.setId(id);
			
			list.add(record);
		}
		
		rs.close();
		ps.close();
		stat.close();
		con.close();
		
		return list;
	}
	public void deleteMessage(String id) throws ClassNotFoundException, SQLException{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","1995494wujiao");
		Statement stat = con.createStatement();
		
		String sql="UPDATE `message` SET ishidden=0 WHERE id='"+id+"'";
		stat.execute(sql);
		
	}
	
	public static void main(String[] args) {
		// TODO 

	}
	
	

}
