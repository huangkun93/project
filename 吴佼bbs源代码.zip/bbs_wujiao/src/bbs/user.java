package bbs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class user {

	public List<comment_bean> readUser() throws SQLException, ClassNotFoundException{
		List<comment_bean> user_list=new ArrayList<comment_bean>();
		
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","199494yin");
		Statement stat = con.createStatement();
		
		String sql="SELECT * FROM `login`";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		
		while(rs.next())
		{
			comment_bean record=new comment_bean();
			
			String username=rs.getString("username");
			int status=rs.getInt("status");
			
			record.setUser_name(username);
			record.setUser_status(status);
			
			user_list.add(record);
		}
		rs.close();
		ps.close();
		stat.close();
		con.close();
		return user_list;
	}
	
	public int punish(String name) throws SQLException, ClassNotFoundException{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","1995494wujiao");
		Statement stat = con.createStatement();
		int flag=0;
		
		String sql="UPDATE `login` SET status=1 WHERE username='"+name+"'";
		PreparedStatement ps=con.prepareStatement(sql);
		stat.execute(sql);
		flag=1;
		return flag;
	}
	
	public int recover(String name) throws SQLException, ClassNotFoundException{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","1995494wujiao");
		Statement stat = con.createStatement();
		int flag=0;
		
		String sql="UPDATE `login` SET status=0 WHERE username='"+name+"'";
		PreparedStatement ps=con.prepareStatement(sql);
		stat.execute(sql);
		flag=1;
		return flag;
	}
	
	public void changeInfo(String before_username,String after_username,String password) throws SQLException, ClassNotFoundException{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","1995494wujiao");
		Statement stat = con.createStatement();
		
		String sql="UPDATE `login` SET username='"+after_username+"' AND password='"+password+"' WHERE username='"+before_username+"'";
		
		stat.execute(sql);
		
	}
	
	public static void main(String[] args) {
//		user tool=new user();
//		tool.punish();

	}

}
