package bbs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class userLogin {

	//��¼
	public int login(String id,String psd) throws ClassNotFoundException, SQLException
	{    
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","199494yin");
		Statement stat = con.createStatement();
		String sql="SELECT username,password FROM `login`";
		int flag=0;
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			String name=rs.getString("username");
			String password=rs.getString("password");
			if(name.equals(id) && password.equals(psd))
			{
				flag=1;
			}
		}
		return flag;
	}
	
	//ע��
	public int regist(String id,String psd) throws ClassNotFoundException, SQLException
	{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","199494yin");
		Statement stat = con.createStatement();
		String sql="SELECT username FROM `login`";
		int flag=0;
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			String name=rs.getString("username");
			if(!name.equals(id))
			{
				flag=1;
			}
		}
		if(id==null)
		{
			flag=0;
		}
		if(flag==1)
		{
			String sql1="INSERT INTO `login` (username,password) VALUES('"+id+"','"+psd+"')";
			stat.execute(sql1);
		}
		return flag;
	}
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		userLogin toolLogin=new userLogin();
		int x=toolLogin.regist(7276+"", 11+"");
		
	}

}
