package bbs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class discuss {

	public void sendDiscuss(String author,String discuss,String title) throws SQLException, ClassNotFoundException{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","199494yin");
		Statement stat = con.createStatement();
		
		Date date=new Date();
		DateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time=format.format(date);
		
		String sql="INSERT INTO `discuss` (discuss,discuss_title,discuss_author,discuss_time) VALUES('"+discuss+"','"+title+"','"+author+"','"+time+"')";
		PreparedStatement ps=con.prepareStatement(sql);
		stat.execute(sql);
	}
	
	public List<comment_bean> getDiscuss(String title) throws SQLException, ClassNotFoundException
	{
		List<comment_bean> discuss_list=new ArrayList<comment_bean>();
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","199494yin");
		Statement stat = con.createStatement();
		
		String sql="SELECT * FROM `discuss` WHERE discuss_title='"+title+"' ORDER BY discuss_time DESC";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		
		while(rs.next())
		{
			comment_bean record=new comment_bean();
			
			String discuss=rs.getString("discuss");
			String discuss_title=rs.getString("discuss_title");
			String discuss_author=rs.getString("discuss_author");
			String discuss_time=rs.getString("discuss_time");
			
			record.setDiscuss(discuss);
			record.setDiscuss_author(discuss_author);
			record.setDiscuss_title(discuss_title);
			record.setDiscuss_time(discuss_time);
			
			discuss_list.add(record);
		}
		rs.close();
		ps.close();
		stat.close();
		con.close();
		return discuss_list;
	}
	
	
	public static void main(String[] args) {
		

	}

}
