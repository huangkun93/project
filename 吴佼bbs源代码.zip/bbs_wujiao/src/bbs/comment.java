package bbs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class comment {

	public void sendComment(String comment_title,String comment,String comment_author,String comment_module) throws SQLException, ClassNotFoundException{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","199594wujiao");
		Statement stat = con.createStatement();
		
		Date date=new Date();
		DateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time=format.format(date);
		
		String sql="INSERT INTO `comment` (comment_title,comment,comment_author,comment_module,comment_time) VALUES('"+comment_title+"','"+comment+"','"+comment_author+"','"+comment_module+"','"+time+"')";
		PreparedStatement ps=con.prepareStatement(sql);
		stat.execute(sql);
	}
	
	//homepage���ܵ������б�����
	public List<comment_bean> getComment() throws ClassNotFoundException, SQLException{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","199494yin");
		Statement stat = con.createStatement();
		
		List<comment_bean> comment_list=new ArrayList<comment_bean>();//��Ӧ��comment_bean�е�����
		
		String sql="SELECT * FROM `comment` WHERE ishidden=1 ORDER BY comment_time DESC";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery(); //��ȡcomment�������е�����
		while (rs.next())
		{
			comment_bean record=new comment_bean();
			String comment_title=rs.getString("comment_title");
			String comment=rs.getString("comment");
			String comment_author=rs.getString("comment_author");
			String comment_module=rs.getString("comment_module");
			String comment_time=rs.getString("comment_time");
			int id=rs.getInt("id");
			
			record.setComment_title(comment_title);
			record.setComment(comment);
			record.setComment_author(comment_author);
			record.setComment_module(comment_module);
			record.setComment_time(comment_time);
			record.setId(id);
			
			comment_list.add(record);
		}
		
		rs.close();
		ps.close();
		stat.close();
		con.close();
		return comment_list;
	}
	
	//ѧϰ����� ��ʾ��������Ϊstudy������
	public List<comment_bean> getCommentFromStudy() throws ClassNotFoundException, SQLException{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","1995494wujiao");
		Statement stat = con.createStatement();
		
		List<comment_bean> comment_list=new ArrayList<comment_bean>();��
		
		String sql="SELECT * FROM `comment` WHERE comment_module='study' ORDER BY comment_time DESC";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		while (rs.next())
		{
			comment_bean record=new comment_bean();
			String comment_title=rs.getString("comment_title");
			String comment=rs.getString("comment");
			String comment_author=rs.getString("comment_author");
			String comment_module=rs.getString("comment_module");
			String comment_time=rs.getString("comment_time");
			int id=rs.getInt("id");
			
			record.setComment_title(comment_title);
			record.setComment(comment);
			record.setComment_author(comment_author);
			record.setComment_module(comment_module);
			record.setComment_time(comment_time);
			record.setId(id);
			
			comment_list.add(record);
		}
		
		rs.close();
		ps.close();
		stat.close();
		con.close();
		return comment_list;
	}
	
	//��������� ��ʾ��������Ϊwork������
	public List<comment_bean> getCommentFromWork() throws ClassNotFoundException, SQLException{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","1995494wujiao");
		Statement stat = con.createStatement();
		
		List<comment_bean> comment_list=new ArrayList<comment_bean>();��
		
		String sql="SELECT * FROM `comment` WHERE comment_module='work' ORDER BY comment_time DESC";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		while (rs.next())
		{
			comment_bean record=new comment_bean();
			String comment_title=rs.getString("comment_title");
			String comment=rs.getString("comment");
			String comment_author=rs.getString("comment_author");
			String comment_module=rs.getString("comment_module");
			String comment_time=rs.getString("comment_time");
			int id=rs.getInt("id");
			
			record.setComment_title(comment_title);
			record.setComment(comment);
			record.setComment_author(comment_author);
			record.setComment_module(comment_module);
			record.setComment_time(comment_time);
			record.setId(id);
			
			comment_list.add(record);
		}
		
		rs.close();
		ps.close();
		stat.close();
		con.close();
		return comment_list;
	}
	
	//���ְ���� ��ʾ��������Ϊentertainment������
	public List<comment_bean> getCommentFromEntertainment() throws ClassNotFoundException, SQLException{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","199494yin");
		Statement stat = con.createStatement();
		
		List<comment_bean> comment_list=new ArrayList<comment_bean>();
		
		String sql="SELECT * FROM `comment` WHERE comment_module='play' ORDER BY comment_time DESC";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		while (rs.next())
		{
			comment_bean record=new comment_bean();
			String comment_title=rs.getString("comment_title");
			String comment=rs.getString("comment");
			String comment_author=rs.getString("comment_author");
			String comment_module=rs.getString("comment_module");
			String comment_time=rs.getString("comment_time");
			int id=rs.getInt("id");
			
			record.setComment_title(comment_title);
			record.setComment(comment);
			record.setComment_author(comment_author);
			record.setComment_module(comment_module);
			record.setComment_time(comment_time);
			record.setId(id);
			
			comment_list.add(record);
		}
		
		rs.close();
		ps.close();
		stat.close();
		con.close();
		return comment_list;
	}
	
	//���ӵ�����˳�����ʱ��˳�����У�����ʱ��Խ������ʾλ��Խǰ
	public List<comment_bean> getCommentByTime(String time) throws SQLException, ClassNotFoundException
	{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","199494yin");
		Statement stat = con.createStatement();
		
		List<comment_bean> comment_list=new ArrayList<comment_bean>();
		
		String sql="SELECT * FROM `comment` WHERE ishidden=1 AND comment_time='"+time+"'";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		while (rs.next())
		{
			comment_bean record=new comment_bean();
			String comment_title=rs.getString("comment_title");
			String comment=rs.getString("comment");
			String comment_author=rs.getString("comment_author");
			String comment_time=rs.getString("comment_time");
			int id=rs.getInt("id");
			
			record.setComment_title(comment_title);
			record.setComment(comment);
			record.setComment_author(comment_author);
			record.setComment_time(comment_time);
			record.setId(id);
			
			comment_list.add(record);
		}
		
		rs.close();
		ps.close();
		stat.close();
		con.close();
		return comment_list;
	}
	
	//ɾ�����Ӳ���
	public void deleteComment(String id) throws ClassNotFoundException, SQLException{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","1995494wujiao");
		Statement stat = con.createStatement();
		
		String sql="UPDATE `comment` SET ishidden=0 WHERE id='"+id+"'";
		stat.execute(sql);
		
	}
	
	public int comment_flag(String name) throws SQLException, ClassNotFoundException{
		int flag=0;
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:dota","root","199494yin");
		Statement stat = con.createStatement();

		String sql="SELECT status FROM `login` WHERE username='"+name+"'";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		while (rs.next())
		{
			int status=rs.getInt("status");
			flag=status;
		}
		rs.close();
		ps.close();
		stat.close();
		con.close();
		return flag;
	}
	
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		comment tool=new comment();
		//tool.sendComment("good day","i eat a lot","wujiao");
		//System.out.println(tool.getCommentByTime("2016-06-14 13:37:32").get(0).comment);
		System.out.println(tool.comment_flag("admin"));
	}

}
