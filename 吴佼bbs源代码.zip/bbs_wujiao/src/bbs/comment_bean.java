package bbs;

public class comment_bean {
//对展示的帖子列表内容实例化
	public String comment_title;
	public String comment;
	public String comment_author;
	public String comment_time;
	public String comment_module;
	public int id;
	
	public String discuss_author;
	public String discuss;
	public String discuss_title;
	public String discuss_time;
	
	public String user_name;
	public int user_status;
	
	public String message;
	public String message_author;
	public String message_time;
	
	
	public String getComment_title() {
		return comment_title;
	}
	public void setComment_title(String comment_title) {
		this.comment_title = comment_title;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getComment_author() {
		return comment_author;
	}
	public void setComment_author(String comment_author) {
		this.comment_author = comment_author;
	}
	public String getComment_time() {
		return comment_time;
	}
	public void setComment_time(String comment_time) {
		this.comment_time = comment_time;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDiscuss_author() {
		return discuss_author;
	}
	public void setDiscuss_author(String discuss_author) {
		this.discuss_author = discuss_author;
	}
	public String getDiscuss() {
		return discuss;
	}
	public void setDiscuss(String discuss) {
		this.discuss = discuss;
	}
	public String getDiscuss_title() {
		return discuss_title;
	}
	public void setDiscuss_title(String discuss_title) {
		this.discuss_title = discuss_title;
	}
	public String getDiscuss_time() {
		return discuss_time;
	}
	public void setDiscuss_time(String discuss_time) {
		this.discuss_time = discuss_time;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public int getUser_status() {
		return user_status;
	}
	public void setUser_status(int user_status) {
		this.user_status = user_status;
	}
	public String getComment_module() {
		return comment_module;
	}
	public void setComment_module(String comment_module) {
		this.comment_module = comment_module;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getMessage_author() {
		return message_author;
	}
	public void setMessage_author(String message_author) {
		this.message_author = message_author;
	}
	public String getMessage_time() {
		return message_time;
	}
	public void setMessage_time(String message_time) {
		this.message_time = message_time;
	}

}
